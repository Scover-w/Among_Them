<?php
/* Auteur : Kyllian Marie-Magdelaine
 * Créer le : 27/05/2020
 * Description : Fichier parametre conservant les informations nécessaires pour la base de données. $host est l'adresse
 * de la base de données, $dbname est le nom de la base de données à utilisé, $username et $password sont les idetifiants
 * Modifié par : Kyllian Marie-Magdelaine
 * Le : 27/05/2020
 * */

$host = "127.0.0.1";
$dbname = "unity_among_them";
$username = "root";
$password = "";
?>
