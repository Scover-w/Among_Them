<html lang="fr">
    <?php include "header.php"; ?>
    <body>
        <?php include "navbar.php"; ?>
        <div class="w-75 bg-main-div position-relative mx-auto my-2">
            <div class="w-auto bg-header-div border-header-div py-2 px-3">
                Register
            </div>

            <form action="data_register.php" method="post" class="d-flex flex-column mx-auto w-50 my-2">
                <div class="d-flex flex-column my-2">
                    <p class="mb-1">Username</p>
                    <input type="text" name="user">
                </div>

                <div class="d-flex flex-column my-2">
                    <p class="mb-1">Password</p>
                    <input type="password" name="pwd">
                </div>

                <div class="d-flex flex-column my-2">
                    <p class="mb-1">Confirm password</p>
                    <input type="password" name="pwdc">
                </div>
                <input class="my-2" type="submit" value="Log In">
            </form>


        </div>
    </body>

</html>
