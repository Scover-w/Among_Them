<?php
include "connexionBDD.php";

$user = isset($_POST['user'])? $_POST['user']: null;
$pwd = isset($_POST['pwd'])? $_POST['pwd']: null;
if (!$user)
{
    header("Location: login.php?fail=1");
}

if (!$pwd)
{
    header("Location: login.php?fail=2");
}

$pwd = hash("md5",$pwd);

$req = "SELECT * FROM `user` WHERE `name` = \"" . $user . "\" AND `password` = \"" . $pwd . "\";";

$req_prep = $bdd->prepare($req);

if ($req_prep->execute())
{
    session_start();
    $user = $req_prep->fetch();
    $_SESSION['username'] = $user[1];
    $_SESSION['user_id'] = $user[0];
    header("Location: index.php");
}else{
    header("Location: login.php?fail=3");
}